// This is just a placeholder for demonstration purposes
// In a real application, you would fetch data from a server

// Sample user data
const users = [
    {
        id: 1,
        username: "user1",
        savedRecipes: [1, 2, 3]
    },
    {
        id: 2,
        username: "user2",
        savedRecipes: [4, 5, 6]
    },
    {
        id: 3,
        username: "user3",
        savedRecipes: [7, 8, 9]
    }
];

// Sample recipe data
const recipes = [
    {
        id: 1,
        title: "Spaghetti Carbonara",
        category: "Pasta",
        ingredients: ["spaghetti", "eggs", "bacon", "parmesan cheese"],
        image: "spaghetti_carbonara.jpg"
    },
    // Add more recipes here
];

// Sample categories
const categories = ["Pasta", "Chicken", "Soup", "Salad", "Dessert"];

// Function to display recipes on the recipes page
function displayRecipes() {
    const recipesSection = document.querySelector(".recipes");

    recipes.forEach(recipe => {
        const recipeCard = document.createElement("div");
        recipeCard.classList.add("recipe-card");
        recipeCard.innerHTML = `
            <h3>${recipe.title}</h3>
            <p>Category: ${recipe.category}</p>
            <img src="images/${recipe.image}" alt="${recipe.title}">
            <p>Ingredients: ${recipe.ingredients.join(", ")}</p>
        `;
        recipesSection.appendChild(recipeCard);
    });
}

// Function to display user profile and saved recipes on the profile page
function displayUserProfile(userId) {
    const userProfileSection = document.querySelector(".user-profile");
    const user = users.find(user => user.id === userId);

    if (user) {
        userProfileSection.innerHTML = `
            <h2>Welcome, ${user.username}!</h2>
            <h3>Your Saved Recipes:</h3>
            <div class="user-recipes">
                <!-- Saved recipes will be dynamically generated here -->
            </div>
        `;

        const userRecipesContainer = userProfileSection.querySelector(".user-recipes");

        user.savedRecipes.forEach(recipeId => {
            const recipe = recipes.find(recipe => recipe.id === recipeId);
            if (recipe) {
                const recipeElement = document.createElement("div");
                recipeElement.classList.add("recipe");
                recipeElement.innerHTML = `
                    <h3>${recipe.title}</h3>
                    <p>Category: ${recipe.category}</p>
                    <img src="images/${recipe.image}" alt="${recipe.title}">
                    <p>Ingredients: ${recipe.ingredients.join(", ")}</p>
                `;
                userRecipesContainer.appendChild(recipeElement);
            }
        });
    } else {
        userProfileSection.innerHTML = "<p>User not found.</p>";
    }
}

// Call functions to display initial content
document.addEventListener("DOMContentLoaded", () => {
    displayRecipes();
    // Assuming user 1 is logged in initially
    displayUserProfile(1);
});

